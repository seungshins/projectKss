
/**
 * Module dependencies.
 */

var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , expressTest = require('./routes/expressTest')
  , http = require('http')
  , path = require('path');

var app = express();

//debug or production mode 

app.settings.env = 'development';
//app.settings.env = 'production';

// all environments
app.set('port', 8199);
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.set('case sensitive routes', true);
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(express.cookieParser('your secret here'));
app.use(express.session());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('production' == app.get('env')) {
  app.use(express.errorHandler());
  console.log("production");
}

// routes
app.get('/', routes.index);
app.get('/response', function(req, res){
    res.render('response', { title: 'what?', header : 'hhhhhh', contentType : 'cccccc'} );
});
app.get('/Redirect', function(req, res){
   res.writeHead(302, {'Location' : 'http://www.naver.com'});
   res.end(); 
   //OR
   //res.redirect('http://www.naver.com');
});
app.get('/expressTest', expressTest.expressTest);
app.get('/expressTestNoIndex', function(req, res){
    res.render('expressTest', { title: 'what?'} );
});
app.get('/users', user.list);
app.get('/life', function(request, response, next){
    //응답
    response.send('<h1>Life Page</h1>', {'Content-Type': 'text/html'}, 200);
//    response.writeHead(200, {'Content-Type': 'text/html'});
//    response.end('<h1>Life Page</h1>');
});

app.get('/life1', function(request, response, next){
    //응답
//    response.send('<h1>Life Page</h1>', {'Content-Type': 'text/html'}, 200);
    response.writeHead(200, {'Content-Type': 'text/html'});
    response.end('<h1>Life Page</h1>');
});

//GET - OnlyChrome
app.get('/OnlyChrome', function(req, res){
    var agent = req.header('User-Agent');
    
    if(agent.toLowerCase().match(/chrome/)){
        res.writeHead(200, {'Content-Type' : 'text/html'});
        res.end('<h1>Welcome Chrome .. !</h1>');
    }else{
        res.redirect('/');
    }
});

app.post('/life2', function(request, response, next){
    response.send('<h1>Life2 POST Success Page</h1>', {'Content-Type': 'text/html'}, 200);
});

app.delete('/life2', function(request, response, next){
    response.send('<h1>Life3 DELETE Success Page</h1>', {'Content-Type': 'text/html'}, 200);
});

app.put('/life2', function(request, response, next){
    response.send('<h1>Life4 put Success Page</h1>', {'Content-Type': 'text/html'}, 200);
});

app.listen(app.get('port'));
console.log('Express server listening on port ' + app.get('port'));


//http.createServer(app).listen(app.get('port'), function(){
//  console.log('Express server listening on port ' + app.get('port'));
//});