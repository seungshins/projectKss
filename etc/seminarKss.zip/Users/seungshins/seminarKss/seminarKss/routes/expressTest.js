
/*
 * GET home page.
 */

exports.expressTest = function(req, res){
  res.render('expressTest', { title: 'what is expressTest?' });
};